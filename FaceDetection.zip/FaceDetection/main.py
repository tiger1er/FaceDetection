import numpy as np
from PIL import Image, ImageDraw
import face_recognition
import numpy

image_drogba = face_recognition.load_image_file('drogba.jpg')
encodage_visage_drogba = face_recognition.face_encodings(image_drogba)[0]
image_etoo = face_recognition.load_image_file('etoo.jpg')
encodage_visage_etoo = face_recognition.face_encodings(image_etoo)[0]

encodage_visage_connu = [
    encodage_visage_drogba,
    encodage_visage_etoo
]

nom_visage_connu = [
    "Didier Drogba",
    "Samuel eto'o"

]

image_iconnu = face_recognition.load_image_file('etodro.jpg')

emp_visage_iconnu = face_recognition.face_locations(image_iconnu)
encodage_visage_inconnu = face_recognition.face_encodings(image_iconnu, emp_visage_iconnu)

image_pil = Image.fromarray(image_iconnu)
draw = ImageDraw.Draw(image_pil)

for (haut, droite, bas, gauche) , encodage_visage in zip(emp_visage_iconnu, encodage_visage_inconnu):
    corresp = face_recognition.compare_faces(encodage_visage_connu, encodage_visage)

    nom = 'inconnu'

    distance_visage = face_recognition.face_distance(encodage_visage_connu, encodage_visage)
    meilleur_indice = np.argmin(distance_visage)
    if corresp[meilleur_indice]:
        nom = nom_visage_connu[meilleur_indice]

    draw.rectangle(((gauche, haut), (droite, bas)), outline=(0,2,255))

    largeur_texte, hauteur_texte = draw.textsize(nom)
    draw.text((gauche + 6, bas - hauteur_texte - 5), nom, fill=(255,255,255))

image_pil.show()

